<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Prescription PDF</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            color: #000;
        }

        .header {
            text-align: center;
            position: relative;
            padding-left: 100px;
        }

        .header img {
            position: absolute;
            top: 0;
            left: 0;
            width: 80px;
            height: auto;
        }

        .header h1, .header p {
            margin: 5px 0;
            padding-left: 10px;
        }

        .section {
            margin: 20px 0;
        }

        .section h3 {
            margin-bottom: 10px;
        }

        .info-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        .info-table th, .info-table td {
            padding: 5px;
            text-align: left;
            border: 1px solid #ddd;
        }

        .info-table th {
            width: 30%;
            background-color: #f4f4f4;
        }

        .prescription {
            margin-top: 10px;
        }

        .prescription p {
            margin: 5px 0;
        }

        .signature {
            text-align: right;
            margin-top: 50px;
        }
    </style>
</head>
<body>
    <div class="page">
        <div class="header">
            <img src="<?php echo e(public_path('images/logo.png')); ?>" alt="Telkom Medika Logo">
            <h1>Telkom Medika</h1>
            <p>Gedung Business Center, Jl. Telekomunikasi, Sukapura, Dayeuhkolot, Bandung Regency, West Java 40257</p>
        </div>
        <div class="section">
            <h3>Copy of Prescription</h3>
            <table class="info-table">
                <tr>
                    <th>No.</th>
                    <td><?php echo e($resource['id']); ?></td>
                </tr>
                <tr>
                    <th>Doctor</th>
                    <td>Dr. <?php echo e($resource['checkup']['doctor']['user']['name']); ?> (<?php echo e($resource['checkup']['doctor']['specialization']); ?>)</td>
                </tr>
                <tr>
                    <th>Patient</th>
                    <td><?php echo e($resource['checkup']['patient']['user']['name']); ?> </td>
                </tr>
            </table>
        </div>
        <div class="prescription">
            <?php $__currentLoopData = $resource['prescription']['prescriptionDetails']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <p>R/ <?php echo e($detail['medicine']['name']); ?> <?php echo e($detail['medicine']['type']); ?> - <?php echo e($detail['quantity']); ?> pcs</p>
                <p>S. <?php echo e($detail['instructions']); ?></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="signature">
            <p>Telkom Medika</p>
            <br><br>
            <p>Dr. <?php echo e($resource['checkup']['doctor']['user']['name']); ?></p>
        </div>
    </div>
</body>
</html>
<?php /**PATH /home/semyid/backendtelkommedikaweblaravel.se4603.my.id/laravel-tubes-api/resources/views/pdf/prescription.blade.php ENDPATH**/ ?>